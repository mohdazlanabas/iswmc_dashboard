
  # Integrated Waste Management Dashboard

  This is a code bundle for Integrated Waste Management Dashboard. The original project is available at https://www.figma.com/design/mewcz9x5PG0tN7V6KiqDJX/Integrated-Waste-Management-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  